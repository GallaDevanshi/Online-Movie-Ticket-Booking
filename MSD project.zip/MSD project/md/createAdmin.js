require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const User = require('./models/User'); // Make sure this path is correct

// Ensure MongoDB URI is available
const mongoURI = process.env.MONGO_URI;
if (!mongoURI) {
    console.error("❌ ERROR: MongoDB URI is not defined in .env file.");
    process.exit(1);
}

// Connect to MongoDB
mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(async () => {
        console.log("✅ Connected to MongoDB");

        try {
            // Check if admin already exists
            const existingAdmin = await User.findOne({ email: 'admin@example.com' });

            if (existingAdmin) {
                console.log("ℹ️ Admin already exists.");
            } else {
                // Hash the admin password
                const hashedPassword = await bcrypt.hash('adminpassword', 10);

                // Create the admin user
                const adminUser = new User({
                    username: 'Admin',
                    email: 'admin@example.com',
                    password: hashedPassword,
                    role: 'admin', // Make sure your User schema supports 'role'
                });

                await adminUser.save();
                console.log("✅ Admin user created successfully!");
            }
        } catch (err) {
            console.error("❌ ERROR: Failed to create admin user:", err);
        } finally {
            mongoose.disconnect();
        }
    })
    .catch(err => {
        console.error("❌ ERROR: Failed to connect to MongoDB:", err);
        process.exit(1);
    });
