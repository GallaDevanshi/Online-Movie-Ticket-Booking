require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const path = require('path');
const User = require('./models/User');
const Movie = require('./models/Movie'); // Import only once
const cors = require("cors");
const jwt = require("jsonwebtoken");


const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(cors());
app.use(bodyParser.json());


// MongoDB Connection
const uri = process.env.MONGO_URI;
if (!uri) {
    console.error('MongoDB URI not defined. Check your .env file.');
    process.exit(1);
}

mongoose
    .connect(uri)
    .then(() => console.log('Connected to MongoDB'))
    .catch(err => {
        console.error('Error connecting to MongoDB:', err);
        process.exit(1);
    });

// Routes
app.get('/', (req, res) => {
    res.send('<h1>Welcome</h1><a href="/register.html">Register</a> | <a href="/login.html">Login</a>');
});

// ✅ User Registration
app.post('/register', async (req, res) => {
    try{
    const {name, email, password } = req.body;

    if (!name || !email || !password) {
        return res.status(400).json({ error: "All fields are required." });
    }


        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ error: "Email already registered." });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const newUser = new User({ name, email, password: hashedPassword }); 
        await newUser.save();

        return res.json({ success: true, message: "User registered successfully!" });return res.json({ success: true, message: "User registered successfully!" });
    } catch (err) {
        console.error('Error during registration:', err);
        return res.status(500).json({ error: "Server error." });
    }
});

// ✅ User & Admin Login
app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).send('<h1>All fields are required.</h1>');
    }

    try {
        console.log("🔍 Searching for user with email:", email); 
        const user = await User.findOne({ email });
        console.log("🛠 Found user:", user); 

        if (!user) {
            return res.status(400).json({ error: "User not found!" });
        }

        console.log("🔑 Entered password:", password);
        console.log("🔒 Stored hashed password:", user.password);


        const isMatch = await bcrypt.compare(password, user.password);
        console.log("✅ Password Match Status:", isMatch);

        if (!isMatch) {
            return res.status(400).json({ error: "Invalid credentials!" });
        }

        // Generate a token (optional but recommended)
        const token = jwt.sign({ userId: user._id }, "yourSecretKey", { expiresIn: "1h" });

        res.json({ message: "Login successful", token });
    } catch (error) {
        console.error("Login error:", error);
        res.status(500).json({ error: "Server error" });
    }
});

// ✅ Admin Dashboard - View All Users
app.get('/admin', async (req, res) => {
    try {
        const users = await User.find({}, '-password'); // Exclude passwords
        const userCount = await User.countDocuments();

        let userTable = '<h1>All Users</h1><table border="1"><tr><th>Username</th><th>Email</th><th>Role</th></tr>';
        users.forEach(user => {
            userTable += `<tr><td>${user.username}</td><td>${user.email}</td><td>${user.role}</td></tr>`;
        });
        userTable += '</table>';
        
        res.send(`<h1>Admin Dashboard</h1><h2>Total Users: ${userCount}</h2>${userTable}`);
    } catch (err) {
        console.error('Error fetching users:', err);
        res.status(500).send('<h1>Internal Server Error</h1>');
    }
});




// Add a new movie
app.post('/add-movie', async (req, res) => {
    const { title, genre } = req.body;
    try {
        const newMovie = new Movie({ title, genre });
        await newMovie.save();
        res.json({ message: "Movie added successfully", movie: newMovie });
    } catch (error) {
        res.status(500).json({ error: "Failed to add movie" });
    }
});

// Get all movies
app.get('/movies', async (req, res) => {
    try {
        const movies = await Movie.find();
        res.json(movies);
    } catch (error) {
        res.status(500).json({ error: "Failed to fetch movies" });
    }
});

// Seat Schema
const seatSchema = new mongoose.Schema({
    seatNumber: String,
    bookedBy: String
});

const Seat = mongoose.model("Seat", seatSchema);

// Get all booked seats
app.get("/get-booked-seats", async (req, res) => {
    try {
        const bookedSeats = await Seat.find();
        res.json({ bookedSeats: bookedSeats.map(seat => seat.seatNumber) });
    } catch (error) {
        res.status(500).json({ error: "Internal Server Error" });
    }
});

// Book seats
app.post("/book-seats", async (req, res) => {
    const { seats, user } = req.body;
    
    try {
        // Check if seats are already booked
        const existingBookings = await Seat.find({ seatNumber: { $in: seats } });

        if (existingBookings.length > 0) {
            return res.status(400).json({ success: false, message: "Some seats are already booked!" });
        }

        // Save new bookings
        const newBookings = seats.map(seat => new Seat({ seatNumber: seat, bookedBy: user }));
        await Seat.insertMany(newBookings);

        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: "Internal Server Error" });
    }
});


// ✅ Start the server (Only Once)
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});

