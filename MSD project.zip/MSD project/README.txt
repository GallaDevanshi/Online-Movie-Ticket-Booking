***************ONLINE MOVIE TICKET BOOKING***************

Project Structure:

md/
├── .env
├── app.js
├── createAdmin.js
├── package.json
├── package-lock.json
├── assets/
│   ├── hello.jpg
│   └── logo2.jpg
├── models/
│   └── Movie.js
├── node_modules/        
└── public/                
      |___home1.html
      |___login.html
      |___register.html
      |___first.html
      |___second.html
      |___fourth.html
      |___fifth.html
      |___payment-summary.html
      |___payment-successful.html
      
  
>>> npm init -y : for initialize node.js 
>>>npm install express body-parser mongoose dotenv bcrypt : for installing requred dependencies
>>>mongod : for running the mongodb (in mongodb shell)
>>>node createAdmin.js #run for atleast once 
>>>node app.js : to run the project    